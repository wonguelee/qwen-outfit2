package com.s25.qwenoutfit

import android.graphics.Bitmap
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.viewmodel.compose.viewModel

private val Navy = Color(0xFF080B18)
private val CardNavy = Color(0xFF131A33)
private val DeepNavy = Color(0xFF0E1430)
private val Purple = Color(0xFF7C5CFF)
private val PurpleSoft = Color(0xFFA98BFF)
private val TextMain = Color(0xFFE8EAF6)
private val TextDim = Color(0xFF9AA3C7)
private val Warn = Color(0xFFFFB44C)

private val PRESETS = listOf(
    "검은색 가죽 자켓",
    "흰색 셔츠와 검은 넥타이",
    "빨간 원피스",
    "파란 청바지에 흰 티셔츠",
    "베이지색 트렌치코트",
    "네이비 정장 수트",
    "오버사이즈 후드티",
    "겨울 패딩 점퍼"
)

/** 드래그 시작점을 기억해두는 작은 상자. */
private class DragState {
    var last: Offset? = null
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Purple,
                    background = Navy,
                    surface = CardNavy,
                    onPrimary = Color.White,
                    onSurface = TextMain
                )
            ) {
                Surface(color = Navy, modifier = Modifier.fillMaxSize()) {
                    val vm: StudioViewModel = viewModel()
                    StudioScreen(vm)
                }
            }
        }
    }
}

/** 이미지를 영역 안에 "비율 유지 + 가운데 정렬"로 그렸을 때의 실제 사각형. */
private fun fitRect(canvasW: Float, canvasH: Float, imageW: Float, imageH: Float): Rect {
    if (canvasW <= 0f || canvasH <= 0f || imageW <= 0f || imageH <= 0f) {
        return Rect(0f, 0f, 0f, 0f)
    }
    val scale = minOf(canvasW / imageW, canvasH / imageH)
    val w = imageW * scale
    val h = imageH * scale
    val left = (canvasW - w) / 2f
    val top = (canvasH - h) / 2f
    return Rect(left, top, left + w, top + h)
}

@Composable
private fun StudioScreen(vm: StudioViewModel) {
    val context = LocalContext.current
    val view = LocalView.current

    // 생성 중에는 화면이 꺼지지 않게 (긴 작업이라 중간에 잠기면 요청이 끊긴다)
    LaunchedEffect(vm.running) { view.keepScreenOn = vm.running }

    val picker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) vm.loadPhoto(context, uri)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(14.dp)
    ) {
        Header(vm)
        Spacer(Modifier.height(12.dp))
        PhotoCard(vm, onPick = { picker.launch("image/*") })
        Spacer(Modifier.height(12.dp))
        PromptCard(vm)
        Spacer(Modifier.height(12.dp))
        RunCard(vm)
        val result = vm.result
        if (result != null) {
            Spacer(Modifier.height(12.dp))
            ResultCard(vm, result)
        }
        Spacer(Modifier.height(24.dp))
    }

    if (vm.showSettings) {
        SettingsDialog(vm)
    }
}

// ---------------------------------------------------------------------- 헤더

@Composable
private fun Header(vm: StudioViewModel) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.width(0.dp).weight(1f)) {
            Text("Qwen 의상 스튜디오", color = TextMain, fontSize = 19.sp, fontWeight = FontWeight.Bold)
            Text("얼굴은 그대로, 옷만 바꾸기", color = TextDim, fontSize = 12.sp)
        }
        TextButton(onClick = { vm.showSettings = true }) {
            Text("설정", color = PurpleSoft)
        }
    }
}

// ------------------------------------------------------------------ 1. 사진

@Composable
private fun PhotoCard(vm: StudioViewModel, onPick: () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = CardNavy),
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("1. 사진", color = PurpleSoft, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.weight(1f))
                Button(
                    onClick = onPick,
                    colors = ButtonDefaults.buttonColors(containerColor = Purple)
                ) { Text("사진 불러오기") }
            }

            Spacer(Modifier.height(10.dp))

            val source = vm.source
            if (source == null) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                        .background(DeepNavy, RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text("아직 사진이 없어", color = TextDim)
                }
            } else {
                MaskCanvas(vm, source, Modifier.fillMaxWidth().height(360.dp))
                Spacer(Modifier.height(4.dp))
                Text(
                    "사진 위를 손가락으로 칠하면 그 부분만 바뀌어.",
                    color = TextDim,
                    fontSize = 11.sp
                )
                Spacer(Modifier.height(8.dp))
                ToolRow(vm)
            }
        }
    }
}

@Composable
private fun MaskCanvas(vm: StudioViewModel, source: Bitmap, modifier: Modifier) {
    val density = LocalDensity.current
    var canvasSize by remember { mutableStateOf(IntSize(0, 0)) }
    val drag = remember(source) { DragState() }

    val sourceImage = remember(source) { source.asImageBitmap() }
    val version = vm.maskVersion
    val maskImage = remember(vm.maskBitmap, version) { vm.maskBitmap?.asImageBitmap() }

    fun radiusInBitmap(): Float {
        val shown = fitRect(
            canvasSize.width.toFloat(), canvasSize.height.toFloat(),
            source.width.toFloat(), source.height.toFloat()
        )
        if (shown.width <= 0f) return 8f
        val screenRadius = with(density) { (vm.brushSize / 2f).dp.toPx() }
        return screenRadius * (source.width.toFloat() / shown.width)
    }

    fun toBitmapPoint(point: Offset): Offset? {
        val shown = fitRect(
            canvasSize.width.toFloat(), canvasSize.height.toFloat(),
            source.width.toFloat(), source.height.toFloat()
        )
        if (shown.width <= 0f || shown.height <= 0f) return null
        val x = (point.x - shown.left) / shown.width * source.width
        val y = (point.y - shown.top) / shown.height * source.height
        if (x < 0f || y < 0f || x >= source.width || y >= source.height) return null
        return Offset(x, y)
    }

    Canvas(
        modifier = modifier
            .background(DeepNavy, RoundedCornerShape(12.dp))
            .onSizeChanged { canvasSize = it }
            .pointerInput(source, vm.eraser) {
                detectTapGestures { point ->
                    val target = toBitmapPoint(point) ?: return@detectTapGestures
                    vm.paint(target.x, target.y, target.x, target.y, radiusInBitmap(), vm.eraser)
                }
            }
            .pointerInput(source, vm.eraser) {
                detectDragGestures(
                    onDragStart = { point ->
                        drag.last = point
                        val target = toBitmapPoint(point)
                        if (target != null) {
                            vm.paint(
                                target.x, target.y, target.x, target.y,
                                radiusInBitmap(), vm.eraser
                            )
                        }
                    },
                    onDrag = { change, _ ->
                        change.consume()
                        val previous = drag.last ?: change.position
                        val from = toBitmapPoint(previous)
                        val to = toBitmapPoint(change.position)
                        if (from != null && to != null) {
                            vm.paint(from.x, from.y, to.x, to.y, radiusInBitmap(), vm.eraser)
                        }
                        drag.last = change.position
                    },
                    onDragEnd = { drag.last = null },
                    onDragCancel = { drag.last = null }
                )
            }
    ) {
        val shown = fitRect(size.width, size.height, source.width.toFloat(), source.height.toFloat())
        val dstOffset = IntOffset(shown.left.toInt(), shown.top.toInt())
        val dstSize = IntSize(shown.width.toInt().coerceAtLeast(1), shown.height.toInt().coerceAtLeast(1))
        drawImage(sourceImage, dstOffset = dstOffset, dstSize = dstSize)
        val mask = maskImage
        if (mask != null) {
            drawImage(mask, dstOffset = dstOffset, dstSize = dstSize)
        }
    }
}

@Composable
private fun ToolRow(vm: StudioViewModel) {
    Column {
        Row(verticalAlignment = Alignment.CenterVertically) {
            ToolButton("브러시", selected = !vm.eraser) { vm.eraser = false }
            Spacer(Modifier.width(8.dp))
            ToolButton("지우개", selected = vm.eraser) { vm.eraser = true }
            Spacer(Modifier.weight(1f))
            Text("굵기 ${vm.brushSize.toInt()}", color = TextDim, fontSize = 12.sp)
        }
        Slider(
            value = vm.brushSize,
            onValueChange = { vm.brushSize = it },
            valueRange = 8f..140f,
            modifier = Modifier.fillMaxWidth()
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            Button(
                onClick = { vm.autoSelectClothes() },
                enabled = !vm.running,
                colors = ButtonDefaults.buttonColors(containerColor = Purple)
            ) { Text("옷 자동 선택") }
            Spacer(Modifier.width(8.dp))
            OutlinedButton(onClick = { vm.invertMask() }) { Text("반전") }
            Spacer(Modifier.width(8.dp))
            OutlinedButton(onClick = { vm.clearMask() }) { Text("지우기") }
        }
        if (!vm.hasAutoModel) {
            Spacer(Modifier.height(6.dp))
            Text(
                "옷 인식 모델이 앱에 없어서 자동 선택을 쓸 수 없어. 손으로 칠하면 돼.",
                color = Warn,
                fontSize = 11.sp
            )
        }
        Spacer(Modifier.height(6.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(
                checked = vm.keepFaceAndHair,
                onCheckedChange = { vm.keepFaceAndHair = it }
            )
            Spacer(Modifier.width(8.dp))
            Text("자동 선택 시 얼굴·머리카락 보호", color = TextDim, fontSize = 12.sp)
        }
    }
}

@Composable
private fun ToolButton(label: String, selected: Boolean, onClick: () -> Unit) {
    if (selected) {
        Button(
            onClick = onClick,
            colors = ButtonDefaults.buttonColors(containerColor = Purple)
        ) { Text(label) }
    } else {
        OutlinedButton(onClick = onClick) { Text(label) }
    }
}

// ---------------------------------------------------------------- 2. 프롬프트

@Composable
private fun PromptCard(vm: StudioViewModel) {
    Card(
        colors = CardDefaults.cardColors(containerColor = CardNavy),
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(12.dp)) {
            Text("2. 어떤 옷으로 바꿀까", color = PurpleSoft, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
            ) {
                PRESETS.forEach { preset ->
                    OutlinedButton(
                        onClick = {
                            vm.prompt = if (vm.prompt.isBlank()) preset else vm.prompt + ", " + preset
                        },
                        modifier = Modifier.padding(end = 6.dp)
                    ) { Text(preset, fontSize = 12.sp) }
                }
            }

            Spacer(Modifier.height(8.dp))

            OutlinedTextField(
                value = vm.prompt,
                onValueChange = { vm.prompt = it },
                label = { Text("프롬프트 (영어도 잘 통해)") },
                placeholder = { Text("예: black leather jacket") },
                minLines = 2,
                maxLines = 5,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(Modifier.height(6.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(
                    checked = vm.autoAppendKeep,
                    onCheckedChange = { vm.autoAppendKeep = it }
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    "얼굴·포즈·배경 유지 문구 자동 추가",
                    color = TextDim,
                    fontSize = 12.sp
                )
            }

            TextButton(onClick = { vm.showAdvanced = !vm.showAdvanced }) {
                Text(if (vm.showAdvanced) "고급 옵션 접기" else "고급 옵션 (부정 프롬프트)", color = PurpleSoft)
            }

            if (vm.showAdvanced) {
                OutlinedTextField(
                    value = vm.negativePrompt,
                    onValueChange = { vm.negativePrompt = it },
                    label = { Text("부정 프롬프트 (넣지 말 것)") },
                    placeholder = { Text("예: blurry, extra fingers") },
                    minLines = 2,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}

// -------------------------------------------------------------------- 3. 실행

@Composable
private fun RunCard(vm: StudioViewModel) {
    Card(
        colors = CardDefaults.cardColors(containerColor = CardNavy),
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(12.dp)) {
            Text("3. 실행", color = PurpleSoft, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Button(
                    onClick = { vm.generate() },
                    enabled = !vm.running && vm.source != null,
                    colors = ButtonDefaults.buttonColors(containerColor = Purple),
                    modifier = Modifier.weight(1f)
                ) { Text(if (vm.running) "만드는 중..." else "옷 바꾸기 실행") }
                Spacer(Modifier.width(8.dp))
                OutlinedButton(onClick = { vm.cancel() }, enabled = vm.running) { Text("취소") }
            }

            if (vm.running) {
                Spacer(Modifier.height(10.dp))
                if (vm.useImg2Img) {
                    LinearProgressIndicator(
                        progress = { vm.progress },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(4.dp))
                    Text("진행률 ${(vm.progress * 100).toInt()}%", color = TextDim, fontSize = 12.sp)
                } else {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(modifier = Modifier.height(18.dp).width(18.dp))
                        Spacer(Modifier.width(10.dp))
                        Text("만들고 있어... (편집 모드는 진행률 표시가 없어)", color = TextDim, fontSize = 12.sp)
                    }
                }
                val preview = vm.preview
                if (preview != null) {
                    Spacer(Modifier.height(8.dp))
                    PreviewStrip(preview)
                }
            }

            Spacer(Modifier.height(10.dp))
            Text(vm.status, color = TextMain, fontSize = 13.sp)

            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedButton(onClick = { vm.checkEngine() }) { Text("엔진 확인") }
                Spacer(Modifier.width(8.dp))
                Text(vm.engineMessage, color = TextDim, fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun PreviewStrip(preview: Bitmap) {
    val image = remember(preview) { preview.asImageBitmap() }
    Canvas(Modifier.fillMaxWidth().height(180.dp)) {
        val shown = fitRect(size.width, size.height, preview.width.toFloat(), preview.height.toFloat())
        drawImage(
            image,
            dstOffset = IntOffset(shown.left.toInt(), shown.top.toInt()),
            dstSize = IntSize(shown.width.toInt().coerceAtLeast(1), shown.height.toInt().coerceAtLeast(1))
        )
    }
}

// -------------------------------------------------------------------- 4. 결과

@Composable
private fun ResultCard(vm: StudioViewModel, result: Bitmap) {
    val source = vm.source
    var fraction by remember { mutableStateOf(0.5f) }

    Card(
        colors = CardDefaults.cardColors(containerColor = CardNavy),
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(12.dp)) {
            Text("4. 결과", color = PurpleSoft, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))

            if (source != null) {
                CompareView(source, result, fraction, Modifier.fillMaxWidth().height(380.dp))
                Slider(
                    value = fraction,
                    onValueChange = { fraction = it },
                    valueRange = 0f..1f,
                    modifier = Modifier.fillMaxWidth()
                )
                Text("← 왼쪽: 원본 / 오른쪽: 결과 →", color = TextDim, fontSize = 11.sp)
            } else {
                PreviewStrip(result)
            }

            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Button(
                    onClick = { vm.saveResult() },
                    colors = ButtonDefaults.buttonColors(containerColor = Purple)
                ) { Text("갤러리에 저장") }
                Spacer(Modifier.width(8.dp))
                OutlinedButton(onClick = { vm.generate() }, enabled = !vm.running) { Text("다시 만들기") }
            }
        }
    }
}

@Composable
private fun CompareView(
    before: Bitmap,
    after: Bitmap,
    fraction: Float,
    modifier: Modifier
) {
    val beforeImage = remember(before) { before.asImageBitmap() }
    val afterImage = remember(after) { after.asImageBitmap() }

    Canvas(modifier.background(DeepNavy, RoundedCornerShape(12.dp))) {
        val shown = fitRect(size.width, size.height, after.width.toFloat(), after.height.toFloat())
        val dstOffset = IntOffset(shown.left.toInt(), shown.top.toInt())
        val dstSize = IntSize(shown.width.toInt().coerceAtLeast(1), shown.height.toInt().coerceAtLeast(1))

        drawImage(afterImage, dstOffset = dstOffset, dstSize = dstSize)
        clipRect(right = shown.left + shown.width * fraction) {
            drawImage(beforeImage, dstOffset = dstOffset, dstSize = dstSize)
        }
        val x = shown.left + shown.width * fraction
        drawLine(
            color = PurpleSoft,
            start = Offset(x, shown.top),
            end = Offset(x, shown.top + shown.height),
            strokeWidth = 3f
        )
    }
}

// -------------------------------------------------------------------- 설정

@Composable
private fun SettingsDialog(vm: StudioViewModel) {
    Dialog(onDismissRequest = { vm.showSettings = false }) {
        Surface(shape = RoundedCornerShape(18.dp), color = CardNavy) {
            Column(
                modifier = Modifier
                    .padding(16.dp)
                    .heightIn(max = 560.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Text("설정", color = TextMain, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(12.dp))

                OutlinedTextField(
                    value = vm.serverUrl,
                    onValueChange = { vm.serverUrl = it },
                    label = { Text("엔진 주소") },
                    placeholder = { Text("http://127.0.0.1:1234") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    "폰에서 엔진을 돌리면 127.0.0.1:1234 / PC 엔진이면 http://192.168.x.x:1234",
                    color = TextDim,
                    fontSize = 11.sp
                )

                Spacer(Modifier.height(12.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(checked = vm.useImg2Img, onCheckedChange = { vm.useImg2Img = it })
                    Spacer(Modifier.width(8.dp))
                    Text("인페인팅 모드 (진행률 %) 사용", color = TextMain, fontSize = 13.sp)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(checked = vm.sendExtraArgs, onCheckedChange = { vm.sendExtraArgs = it })
                    Spacer(Modifier.width(8.dp))
                    Text("엔진 세부옵션 함께 보내기", color = TextMain, fontSize = 13.sp)
                }

                Spacer(Modifier.height(12.dp))
                NumberSlider("스텝(샘플 수)", vm.steps, 1f..30f) { vm.steps = it }
                NumberSlider("CFG (프롬프트 반영 정도)", vm.cfgScale, 1f..7f) { vm.cfgScale = it }
                NumberSlider("Flow shift", vm.flowShift, 0f..6f) { vm.flowShift = it }
                NumberSlider("변화 강도 (strength)", vm.strength, 0.2f..1f) { vm.strength = it }

                OutlinedTextField(
                    value = vm.seedText,
                    onValueChange = { vm.seedText = it },
                    label = { Text("시드 (-1 = 매번 랜덤)") },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(Modifier.height(14.dp))
                Row(horizontalArrangement = Arrangement.End, modifier = Modifier.fillMaxWidth()) {
                    Button(
                        onClick = { vm.showSettings = false },
                        colors = ButtonDefaults.buttonColors(containerColor = Purple)
                    ) { Text("닫기") }
                }
            }
        }
    }
}

@Composable
private fun NumberSlider(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onChange: (Float) -> Unit
) {
    Column {
        Text(
            "$label — ${(value * 100).toInt() / 100f}",
            color = TextDim,
            fontSize = 12.sp
        )
        Slider(
            value = value,
            onValueChange = onChange,
            valueRange = range,
            modifier = Modifier.fillMaxWidth()
        )
    }
}