package com.s25.qwenoutfit

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Call
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.concurrent.TimeUnit

/**
 * 폰(또는 PC) 안에서 돌아가는 로컬 엔진(sd-server)과 대화하는 부분.
 *
 * 왜 이렇게 만들었나 — 예전 버전은 "한 번 실패하면 끝"이었는데,
 * 실제로는 서버 버전에 따라 필드 이름이 `image[]` 일 때도 `image` 일 때도 있고,
 * 엔진에 넘기는 세부옵션을 못 받는 버전도 있어. 그래서 여기서는
 * **될 때까지 순서대로 다른 방식으로 다시 시도**한다. (최대 4번)
 *
 *   1) /v1/images/edits + image[] + 세부옵션
 *   2) /v1/images/edits + image[] + 옵션 없이
 *   3) /v1/images/edits + image  + 세부옵션
 *   4) /v1/images/edits + image  + 옵션 없이
 *   (인페인팅 모드면 /sdapi/v1/img2img 로 같은 방식)
 */
class QwenEngineClient(baseUrl: String) {

    private val root: String = baseUrl.trim().trimEnd('/')

    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(0, TimeUnit.MILLISECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .callTimeout(0, TimeUnit.MILLISECONDS)
        .build()

    @Volatile
    private var runningCall: Call? = null

    enum class Mode { EDITS, IMG2IMG }

    data class EditParams(
        val prompt: String,
        val negativePrompt: String = "",
        val width: Int,
        val height: Int,
        val steps: Int = 8,
        val cfgScale: Double = 2.5,
        val flowShift: Double = 3.0,
        val strength: Double = 0.85,
        val seed: Long = -1L,
        val mode: Mode = Mode.EDITS,
        val sendExtraArgs: Boolean = true
    )

    data class EditResult(val bitmap: Bitmap?, val error: String?)

    data class EngineStatus(val ok: Boolean, val modelName: String?, val message: String)

    fun cancel() {
        try {
            runningCall?.cancel()
        } catch (e: Exception) {
            // 이미 끝난 요청이면 그냥 무시
        }
        runningCall = null
    }

    // ---------------------------------------------------------------- 엔진 상태

    /** 엔진이 켜져 있는지, 그리고 모델이 로드됐는지 확인. */
    suspend fun check(): EngineStatus = withContext(Dispatchers.IO) {
        val first = tryCapabilities()
        if (first.ok) return@withContext first
        val second = tryOptions()
        if (second.ok) return@withContext second
        second
    }

    private fun tryCapabilities(): EngineStatus {
        return try {
            val call = client.newCall(
                Request.Builder().url("$root/sdcpp/v1/capabilities").get().build()
            )
            call.execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful || body.isBlank()) {
                    return EngineStatus(false, null, "HTTP ${response.code}")
                }
                val json = JSONObject(body)
                val model = json.optJSONObject("model")
                val name = model?.optString("name", "")?.takeIf { it.isNotBlank() }
                    ?: model?.optString("stem", "")?.takeIf { it.isNotBlank() }
                if (name == null) {
                    EngineStatus(
                        true, null,
                        "엔진은 켜졌지만 모델이 아직 로드되지 않았어. sd-server 창의 로그를 확인해줘."
                    )
                } else {
                    EngineStatus(true, name, "엔진 연결됨 — 모델: $name")
                }
            }
        } catch (e: Exception) {
            EngineStatus(false, null, friendly(e))
        }
    }

    private fun tryOptions(): EngineStatus {
        return try {
            val call = client.newCall(
                Request.Builder().url("$root/sdapi/v1/options").get().build()
            )
            call.execute().use { response ->
                if (!response.isSuccessful) {
                    return EngineStatus(false, null, "HTTP ${response.code}")
                }
                val json = JSONObject(response.body?.string().orEmpty())
                val name = json.optString("sd_model_checkpoint", "").takeIf { it.isNotBlank() }
                EngineStatus(true, name, "엔진 연결됨" + if (name != null) " — 모델: $name" else "")
            }
        } catch (e: Exception) {
            EngineStatus(false, null, friendly(e))
        }
    }

    /** 인페인팅 모드에서만 의미가 있는 진행률 조회. */
    suspend fun progressOnce(): Pair<Float, Bitmap?> = withContext(Dispatchers.IO) {
        try {
            val call = client.newCall(
                Request.Builder()
                    .url("$root/sdapi/v1/progress?skip_current_image=false")
                    .get()
                    .build()
            )
            call.execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful || body.isBlank()) return@withContext (0f to null)
                val json = JSONObject(body)
                val value = json.optDouble("progress", 0.0).toFloat().coerceIn(0f, 1f)
                // v4: decodeBase64 는 ByteArray? 를 돌려주는데 함수 선언은 Bitmap? 이라
                //     타입이 어긋나 컴파일이 안 됐다. 여기서 바로 그림으로 바꿔준다.
                val preview = json.optString("current_image", "")
                val previewBytes = if (preview.isBlank()) null else decodeBase64(preview)
                val previewBitmap: Bitmap? = if (previewBytes == null) {
                    null
                } else {
                    BitmapFactory.decodeByteArray(previewBytes, 0, previewBytes.size)
                }
                value to previewBitmap
            }
        } catch (e: Exception) {
            0f to null
        }
    }

    // ------------------------------------------------------------------- 생성

    suspend fun edit(source: Bitmap, mask: Bitmap?, params: EditParams): EditResult {
        return withContext(Dispatchers.IO) {
            val sourcePng = ImageUtils.toPngBytes(source)
            val maskPng = mask?.let { ImageUtils.maskToPngBytes(it) }

            val prompts = ArrayList<String>(2)
            if (params.sendExtraArgs) prompts.add(withExtraArgs(params))
            prompts.add(params.prompt)

            var lastError = "엔진이 응답하지 않았어."

            for (prompt in prompts) {
                val bytes: ByteArray? = try {
                    if (params.mode == Mode.IMG2IMG) {
                        postImg2Img(sourcePng, maskPng, prompt, params)
                    } else {
                        postEdits(sourcePng, maskPng, prompt, params)
                    }
                } catch (e: Exception) {
                    lastError = friendly(e)
                    null
                }

                if (bytes != null) {
                    val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                    if (bitmap != null) return@withContext EditResult(bitmap, null)
                    lastError = "돌려받은 이미지를 열 수 없었어."
                }
            }
            EditResult(null, lastError)
        }
    }

    /** 진행률(%)을 볼 수 있고 취소도 잘 되는 방식. */
    private fun postImg2Img(
        sourcePng: ByteArray,
        maskPng: ByteArray?,
        prompt: String,
        params: EditParams
    ): ByteArray? {
        val json = JSONObject()
        json.put("prompt", prompt)
        json.put("negative_prompt", params.negativePrompt)
        json.put("init_images", JSONArray().put(toBase64(sourcePng)))
        json.put("denoising_strength", params.strength)
        json.put("steps", params.steps)
        json.put("cfg_scale", params.cfgScale)
        json.put("sampler_name", "euler")
        json.put("width", params.width)
        json.put("height", params.height)
        json.put("seed", params.seed)
        json.put("batch_size", 1)
        json.put("inpainting_mask_invert", 0)
        if (maskPng != null) {
            json.put("mask", toBase64(maskPng))
        }

        val body = json.toString().toRequestBody(JSON_TYPE)
        val call = client.newCall(
            Request.Builder().url("$root/sdapi/v1/img2img").post(body).build()
        )
        runningCall = call
        try {
            call.execute().use { response ->
                val text = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    throw IllegalStateException(short("HTTP ${response.code} — ", text))
                }
                return extractImageBytes(text)
            }
        } finally {
            runningCall = null
        }
    }

    /** Qwen Image Edit 에 맞는 정식 방식. 필드 이름 두 가지를 모두 시도한다. */
    private fun postEdits(
        sourcePng: ByteArray,
        maskPng: ByteArray?,
        prompt: String,
        params: EditParams
    ): ByteArray? {
        var lastError: String? = null

        for (field in arrayOf("image[]", "image")) {
            val builder = MultipartBody.Builder().setType(MultipartBody.FORM)
                .addFormDataPart(field, "input.png", sourcePng.toRequestBody(PNG_TYPE))
                .addFormDataPart("prompt", prompt)
                .addFormDataPart("n", "1")
                .addFormDataPart("size", "${params.width}x${params.height}")
                .addFormDataPart("output_format", "png")
            if (maskPng != null) {
                builder.addFormDataPart("mask", "mask.png", maskPng.toRequestBody(PNG_TYPE))
            }

            val call = client.newCall(
                Request.Builder().url("$root/v1/images/edits").post(builder.build()).build()
            )
            runningCall = call
            try {
                call.execute().use { response ->
                    val text = response.body?.string().orEmpty()
                    if (response.isSuccessful) {
                        val bytes = extractImageBytes(text)
                        if (bytes != null) return bytes
                        lastError = short("응답에서 이미지를 못 찾았어: ", text)
                    } else {
                        lastError = short("HTTP ${response.code} — ", text)
                    }
                }
            } catch (e: Exception) {
                lastError = friendly(e)
            } finally {
                runningCall = null
            }
        }
        throw IllegalStateException(lastError ?: "알 수 없는 오류")
    }

    // ------------------------------------------------------------- 프롬프트/응답

    /**
     * OpenAI 호환 API 는 서버 버전에 따라 못 받는 옵션이 있어서,
     * 프롬프트 뒤에 native 옵션을 붙여 보낸다. (이건 "시도"일 뿐이고,
     * 실패하면 옵션 없이 다시 보낸다.)
     */
    private fun withExtraArgs(params: EditParams): String {
        val guidance = JSONObject().put("txt_cfg", params.cfgScale)
        val sample = JSONObject()
            .put("scheduler", "euler")
            .put("sample_method", "euler")
            .put("sample_steps", params.steps)
            .put("flow_shift", params.flowShift)
            .put("guidance", guidance)
        val extras = JSONObject()
            .put("strength", params.strength)
            .put("sample_params", sample)
        return params.prompt + "<sd_cpp_extra_args>" + extras.toString() + "</sd_cpp_extra_args>"
    }

    /** images[0] 또는 data[0].b64_json 을 찾아 바이트로. */
    private fun extractImageBytes(text: String): ByteArray? {
        return try {
            val json = JSONObject(text)
            val first: String? = when {
                json.has("images") -> json.optJSONArray("images")?.optString(0, null)
                json.has("data") -> json.optJSONArray("data")
                    ?.optJSONObject(0)
                    ?.optString("b64_json", null)
                else -> null
            }
            if (first.isNullOrBlank()) return null
            decodeBase64(first)
        } catch (e: Exception) {
            null
        }
    }

    private fun decodeBase64(value: String): ByteArray? {
        return try {
            val clean = if (value.contains(",")) value.substring(value.indexOf(",") + 1) else value
            Base64.decode(clean, Base64.DEFAULT)
        } catch (e: Exception) {
            null
        }
    }

    private fun toBase64(bytes: ByteArray): String = Base64.encodeToString(bytes, Base64.NO_WRAP)

    private fun short(prefix: String, text: String): String {
        val trimmed = text.replace("\n", " ").take(180)
        return prefix + trimmed
    }

    /** 사용자가 알아볼 수 있는 말로 바꾼다. */
    private fun friendly(e: Exception): String = when (e) {
        is UnknownHostException, is ConnectException ->
            "엔진에 연결할 수 없어. 주소를 확인해줘 (기본 http://127.0.0.1:1234). PC 엔진이면 같은 와이파이인지도 확인."
        is SocketTimeoutException -> "엔진 응답이 너무 늦어. 모델이 아직 로딩 중일 수 있어."
        else -> e.message ?: e.javaClass.simpleName
    }

    private companion object {
        val PNG_TYPE = "image/png".toMediaType()
        val JSON_TYPE = "application/json; charset=utf-8".toMediaType()
    }
}