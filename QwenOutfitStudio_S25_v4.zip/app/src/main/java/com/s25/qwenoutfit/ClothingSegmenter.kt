package com.s25.qwenoutfit

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.framework.image.ByteBufferExtractor
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.ImageProcessingOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.imagesegmenter.ImageSegmenter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * 옷(의상)만 자동으로 골라내는 부분.
 *
 * MediaPipe 의 "셀피 여러 부위 인식" 모델(selfie_multiclass_256x256.tflite)이
 * 사진의 모든 픽셀을 6가지로 나눠준다.
 *   0 = 배경, 1 = 머리카락, 2 = 몸 피부, 3 = 얼굴 피부, 4 = 옷, 5 = 액세서리
 *
 * 그래서 4번(옷)만 선택하면 "얼굴·머리·배경은 건드리지 않고 옷만 바꾸는"
 * 마스크가 자동으로 만들어진다. 모델 파일이 없거나 실패하면 null 을 돌려주고,
 * 앱은 손가락 브러시로 넘어간다.
 *
 * ── v4 에서 고친 부분 (2026-10-27) ──────────────────────────────────
 *  1) 콜백 방식 `segment(image) { 결과 -> ... }` 는 이 MediaPipe 버전에 없는 함수였다.
 *     → 공식 사용법대로 `segment(image, ImageProcessingOptions)` 를 그대로 호출한다.
 *  2) `categoryMask()` 가 돌려주는 것은 `MPMask` 가 아니라 `MPImage` 다.
 *     그래서 `mask.getBuffer()` 라는 함수가 없었다.
 *     → 공식 샘플과 같이 `ByteBufferExtractor.extract(mask)` 로 꺼낸다.
 *  3) `ImageSegmenterResult` 에는 `close()` 가 없다. (호출하면 컴파일 오류)
 */
class ClothingSegmenter(private val context: Context) {

    companion object {
        const val MODEL_ASSET = "selfie_multiclass_256x256.tflite"
        const val CATEGORY_BACKGROUND = 0
        const val CATEGORY_HAIR = 1
        const val CATEGORY_BODY_SKIN = 2
        const val CATEGORY_FACE_SKIN = 3
        const val CATEGORY_CLOTHES = 4
        const val CATEGORY_ACCESSORY = 5
    }

    private var segmenter: ImageSegmenter? = null

    fun modelAvailable(): Boolean {
        return try {
            context.assets.open(MODEL_ASSET).use { true }
        } catch (e: Exception) {
            false
        }
    }

    private fun ensureSegmenter(): ImageSegmenter? {
        val cached = segmenter
        if (cached != null) return cached
        if (!modelAvailable()) return null
        return try {
            val options = ImageSegmenter.ImageSegmenterOptions.builder()
                .setBaseOptions(BaseOptions.builder().setModelAssetPath(MODEL_ASSET).build())
                .setRunningMode(RunningMode.IMAGE)
                .setOutputCategoryMask(true)
                .setOutputConfidenceMasks(false)
                .build()
            ImageSegmenter.createFromOptions(context, options).also { segmenter = it }
        } catch (e: Exception) {
            null
        }
    }

    /** 모델이 알려준 "부위 지도". raw[픽셀번호] = 그 픽셀의 부위 번호(0~5). */
    private class CategoryMap(val width: Int, val height: Int, val raw: ByteArray)

    /**
     * @param keepFaceAndHair true 면 옷 영역만, false 면 옷+몸 피부까지 선택한다.
     * @return 원본과 같은 크기의 화면용 마스크(선택된 곳만 반투명 빨강). 실패하면 null.
     */
    suspend fun clothesMask(source: Bitmap, keepFaceAndHair: Boolean): Bitmap? {
        val map = withContext(Dispatchers.IO) { detectCategories(source) } ?: return null
        val selected = BooleanArray(map.width * map.height)
        for (i in selected.indices) {
            val category = map.raw[i].toInt() and 0xFF
            selected[i] = when {
                category == CATEGORY_CLOTHES -> true
                !keepFaceAndHair && category == CATEGORY_BODY_SKIN -> true
                else -> false
            }
        }
        return withContext(Dispatchers.Default) {
            buildMaskBitmap(selected, map.width, map.height, source)
        }
    }

    /**
     * 모델을 돌려서 부위 지도를 얻는다. (무거운 작업이라 IO 스레드에서 호출할 것)
     *
     * 0.10.x 버전에서 categoryMask() 가 돌려주는 MPImage 안에는
     * 픽셀당 1바이트(부위 번호)가 들어 있고, 그 바이트는 ByteBufferExtractor 로 꺼낸다.
     */
    private fun detectCategories(source: Bitmap): CategoryMap? {
        val engine = ensureSegmenter() ?: return null
        return try {
            val mpImage = BitmapImageBuilder(source).build()
            val options = ImageProcessingOptions.builder().build()
            val result = engine.segment(mpImage, options)

            val optional = result.categoryMask()
            if (!optional.isPresent) return null
            val mask = optional.get()
            val width = mask.width
            val height = mask.height
            if (width <= 0 || height <= 0) return null

            val buffer = ByteBufferExtractor.extract(mask)
            val count = width * height
            if (buffer.capacity() < count) return null

            val raw = ByteArray(count)
            for (i in 0 until count) {
                raw[i] = buffer.get(i)
            }
            CategoryMap(width, height, raw)
        } catch (e: Exception) {
            null
        }
    }

    /**
     * 작은(256x256) 부위 지도를 원본 크기로 늘리면서,
     * 경계를 1픽셀 안쪽으로 줄여서 피부·머리카락을 건드리지 않게 한다.
     */
    private fun buildMaskBitmap(
        selected: BooleanArray,
        width: Int,
        height: Int,
        source: Bitmap
    ): Bitmap? {
        if (width <= 2 || height <= 2) return null
        val eroded = erode(selected, width, height)
        val smallPixels = IntArray(width * height)
        for (i in smallPixels.indices) {
            smallPixels[i] = if (eroded[i]) Color.argb(150, 255, 70, 90) else Color.TRANSPARENT
        }
        val small = Bitmap.createBitmap(smallPixels, width, height, Bitmap.Config.ARGB_8888)
        val mask = ImageUtils.createEmptyMask(source.width, source.height)
        val canvas = Canvas(mask)
        val paint = Paint().apply {
            isAntiAlias = true
            isFilterBitmap = true
            alpha = 255
        }
        canvas.drawBitmap(
            small,
            Rect(0, 0, width, height),
            Rect(0, 0, source.width, source.height),
            paint
        )
        small.recycle()
        return mask
    }

    /** 1픽셀 침식 — 선택 영역을 살짝 줄여 경계(피부)를 보호한다. */
    private fun erode(src: BooleanArray, width: Int, height: Int): BooleanArray {
        val out = BooleanArray(src.size)
        for (y in 1 until height - 1) {
            for (x in 1 until width - 1) {
                val i = y * width + x
                if (!src[i]) continue
                out[i] = src[i - 1] && src[i + 1] && src[i - width] && src[i + width]
            }
        }
        return out
    }
}